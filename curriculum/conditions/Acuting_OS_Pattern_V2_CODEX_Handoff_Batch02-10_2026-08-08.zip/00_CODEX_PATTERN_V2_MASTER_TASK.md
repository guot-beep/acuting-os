# AcuTing OS — Pattern V2 Codex Master Task

## Role
You are the repository-aware reconciliation and implementation agent for AcuTing OS Pattern V2. The Batch 02–10 files are a research corpus, not production truth and not a migration script.

## 1. Audit the live repository first
Report current branch, HEAD, worktree status, whether `c8a5ea7` is an ancestor of HEAD, registry raw/category/clinical counts, library raw/active/deprecated counts, and active registry↔library reconciliation.

Verification target:
- registry total 69 = 10 taxonomy/category + 59 clinical `level:"pattern"`
- library raw 62 = 59 active + 3 deprecated
- active reconciliation 59/59

If the live repo does not match, STOP and explain. Do not reset, rebase, pull, or mutate data merely to force a match.

## 2. V1 is frozen
Do not silently rename, merge, delete, or reinterpret V1 canonical IDs. Do not delete the 3 deprecated historical records. Do not reopen the locked Stomach Heat vs Stomach Fire decision. New Pattern work belongs to V2 unless an explicit migration is approved.

## 3. Read all Batch 02–10 files completely
Highest-leverage synthesis files are Batch 05, 09, and 10, but do not skip Batch 03, 04, 06, 07, or 08.

## 4. Reconcile every research concept
Classify each as exactly one primary action:
`KEEP_EXISTING`, `ENRICH_EXISTING`, `ADD_ALIAS`, `NEW_CANONICAL_CANDIDATE`, `SUBTYPE_REVIEW`, `BROADER_NARROWER_REVIEW`, `GRAPH_COMPOSITION`, `PROGRESSION_RELATION`, `CROSS_SYSTEM_OVERLAP`, `TDIS_CONTEXT_ONLY`, `CONTEXT_RELATION`, `LOCATION_MODIFIER`, `TERMINOLOGY_REVIEW`, or `HOLD_INSUFFICIENT_EVIDENCE`.

Chinese canonical identity comes before English wording. Formula wording is evidence, not ontology authority. TCM disease, biomedical condition, channel route, point indication, Luo/Jingjin data, and Pattern identity must remain separate. Cross-system overlap is not alias identity.

## 5. Mandatory Batch 07 coverage
Explicitly decide every one of these before proposing edges:
- 太陽中風 Tai Yang Zhong Feng
- 太陽傷寒 Tai Yang Shang Han
- 陽明經證 Yang Ming Jing
- 陽明腑證 Yang Ming Fu
- 少陽證 Shao Yang
- 太陰虛寒 Tai Yin Deficiency-Cold
- 少陰寒化 Shao Yin Cold Transformation
- 少陰熱化 Shao Yin Heat Transformation
- 厥陰寒熱錯雜 Jue Yin Mixed Cold-Heat
- 衛分風熱 Wei-stage Wind-Heat
- 氣分熱 Qi-stage Heat
- 營分熱 Ying-stage Heat
- 血分熱 Xue-stage Heat
- 氣分濕熱 Qi-stage Damp-Heat
- 三焦濕熱 San Jiao Damp-Heat
- 中焦濕熱 Middle Jiao Damp-Heat
- 下焦濕熱 Lower Jiao Damp-Heat

For each use: `NEW_CANONICAL / SUBTYPE / CROSSWALK_ONLY / LOCATION_MODIFIER / HOLD`. No relation may reference an unresolved Pattern endpoint.

## 6. Mandatory Batch 08 coverage
Explicitly reconcile:
- 帶脈失約 Dai Mai Dysfunction
- 陰蹻脈失調 Yin Qiao imbalance
- 陽蹻脈失調 Yang Qiao imbalance
- 陽維脈失調 Yang Wei disharmony
- 衝氣上逆 Chong Qi Rebellion
- 經絡氣血痹阻 Channel Qi-Blood Obstruction
- 痰阻經絡 Phlegm Obstructing Channels
- 血瘀阻絡 Blood Stasis Obstructing Channels
- 經筋拘急 Sinew-Channel Contraction

## 7. High-risk candidates requiring explicit ontology review
Do not auto-promote: 胃寒, 胃氣上逆, 津傷, 痰飲, 胃絡瘀血, 血虛寒凝, 陰虛火旺.
Also explicitly review rather than discard: 心腎陰虛, 心肝血虛, 腎陽虛水泛, 風痰, 痰熱蒙閉心竅. Heart-Kidney Yin Deficiency must remain distinct from Heart-Kidney Not Communicating.

## 8. Alias caution
Do not hard-alias `肝氣犯胃` to `pattern.liver_stomach_disharmony` until the live canonical Chinese identity/mechanism proves exact equivalence. Decide exact alias vs narrower subtype vs related Pattern.

## 9. Bi hierarchy
Do not invent a noncanonical Bi Pattern umbrella. Prefer `tdis.bi_syndrome -> may_have_pattern -> ...` unless a real registered taxonomy node already exists.

## 10. Relation-registry gate
Do not add relation types in this pass. For every proposed relation semantic in Batch 10, report: `proposed semantic | closest existing live relation type | sufficient? | real semantic gap? | recommended action`. Reuse live vocabulary where adequate.

## 11. Endpoint-ID audit
Resolve the actual live namespace/ID for every proposed graph endpoint, including Dampness, Phlegm, Heat, Cold, Water Flooding, Blood, organ nodes, channels, stage nodes, pregnancy context, San Jiao locations, and extraordinary vessels. If no canonical endpoint exists, keep the relation STAGING_ONLY. Do not invent IDs.

## 12. First deliverable only
Create `PATTERN_V2_CODEX_CANONICAL_REVIEW.md` containing:
A. verified V1 baseline and commands/files used
B. complete Batch 02–10 candidate reconciliation
C. proposed new canonical Patterns
D. proposed aliases
E. subtype/broader-narrower decisions
F. graph-composition-only concepts
G. Six-Channel / Four-Level / San-Jiao decisions
H. extraordinary-vessel / channel-system decisions
I. TCM disease/context-only concepts
J. cross-system mappings
K. graph edges with resolved endpoint IDs, or STAGING_ONLY
L. existing-vs-new relation semantic matrix
M. conflicts / missing evidence / decisions requiring Ting
N. projected V2 counts with explicit arithmetic
O. small dependency-aware implementation batches

## 13. STOP POINT
Stop after producing the review artifact. Do not create Pattern IDs, edit production registry/library, add aliases, add relation types, write production graph edges, redesign schema, or commit implementation changes. Report branch, HEAD, V1 audit result, review artifact path, classification counts, and unresolved human decisions, then wait for Ting.
