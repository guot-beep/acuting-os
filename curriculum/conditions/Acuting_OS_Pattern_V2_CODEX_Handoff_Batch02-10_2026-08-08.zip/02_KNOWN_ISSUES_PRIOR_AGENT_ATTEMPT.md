# Known Issues from Prior Agent Attempt

Reference only. Do not inherit these assumptions.

A prior external-agent review had these problems:
1. It used an old 61 registry / 51 clinical / 50 library baseline instead of the frozen 69 / 59 / 62 / 59 / 3 state.
2. It projected V2 counts from that stale baseline.
3. It under-covered Batch 07 Six-Channel, Four-Level, and San-Jiao candidates.
4. It under-covered Batch 08 extraordinary-vessel and channel candidates.
5. It proposed graph edges whose endpoints had no resolved production ID/namespace.
6. It proposed 13 new relation types before proving the live relation registry could not express those semantics.
7. It labeled some unresolved candidates as low-risk implementation.
8. It proposed a hard alias 肝氣犯胃 → 肝胃不和 without proving exact identity.
9. It created hierarchy ambiguity around Bi by mixing a conceptual Pattern umbrella with `tdis.bi_syndrome`.

Perform a fresh live-repository audit and independent reconciliation.
