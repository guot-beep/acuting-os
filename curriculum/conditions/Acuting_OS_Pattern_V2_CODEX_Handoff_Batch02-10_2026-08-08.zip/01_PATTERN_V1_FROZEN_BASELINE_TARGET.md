# Pattern V1 Frozen Baseline — Verification Target

This is a verification target, not a substitute for auditing the live repository.

Accepted final V1 target:
- Registry total: 69
- Taxonomy/category: 10
- Clinical `level:"pattern"`: 59
- Library raw: 62
- Active canonical: 59
- Deprecated historical: 3
- Active clinical registry ↔ active library: 59/59

Known final-three implementation commit: `c8a5ea7`
Final three cards: `pattern.stomach_fire`, `pattern.wind_cold`, `pattern.wind_heat`.

Locked decisions:
- Stomach Heat and Stomach Fire remain distinct canonical IDs.
- Heart-Kidney Not Communicating remains distinct from Heart-Kidney Yin Deficiency.
- Deprecated historical imports remain historical provenance, not active cards.
